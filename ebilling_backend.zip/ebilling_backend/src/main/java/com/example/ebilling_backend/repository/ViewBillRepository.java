import org.springframework.data.jpa.repository.JpaRepository;
import com.example.ebilling_backend
.model.ViewBill;

public interface ViewBillRepository extends JpaRepository<ViewBill, Long> {
}
